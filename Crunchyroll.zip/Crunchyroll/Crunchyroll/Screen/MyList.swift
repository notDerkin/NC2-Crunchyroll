//
//  MyList.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 07/12/21.
//

import SwiftUI

struct MyList: View {
    var animeList: [Anime]
    @State private var showFavoritesOnly = true
    
    
    var filteredAnime: [Anime] {
        animeList.filter { anime in
            (!showFavoritesOnly || anime.isSaved)
        }
    }
    @State var isShowingAnime = false
    @State private var selectedAnime : Anime? = nil
    
    var body: some View {
        NavigationView {
            VStack {
                MyListNavBar()
                
                ScrollView {
                    VStack {
                        ForEach(filteredAnime) { anime in
                            AnimeRow(anime: anime)
                                .onTapGesture {
                                    isShowingAnime.toggle()
                                    self.selectedAnime = anime
                                }
                        }.fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                            AnimeDetails(anime: selectedAnime)
                        })
                            
                    }
                }
                
            }
            .navigationBarHidden(true)
        }
    }
}

