//
//  ContentView.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 06/12/21.
//

import SwiftUI

struct MainView: View {
    @EnvironmentObject var appData: AppData
    @State private var selectedTab = "home"
    var body: some View {
        TabView(selection: $selectedTab) {
            AnimeList(animeList: appData.animeList)
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
                .tag("home")
            
            MyList(animeList: appData.animeList)
                .tabItem {
                    Image(systemName: "bookmark")
                    Text("My List")
                }
                .tag("myList")
            
            Text("Browse")
                .tabItem {
                    Image(systemName: "square.grid.2x2")
                    Text("Browse")
                }
                .tag("browse")
            
            Text("Simulcast")
                .tabItem {
                    Image(systemName: "sparkles")
                    Text("Simulcast")
                }
                .tag("simulcast")
            
            Text("Account")
                .tabItem {
                        Image("crunch")
                            .resizable()
                            .scaledToFit()
                    Text("Account")
                }
                .tag("account")
            
        }
        .accentColor(Color.customOrange)
    }
}
