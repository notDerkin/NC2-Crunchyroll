//
//  EpisodeCard.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 10/12/21.
//

import Foundation
import SwiftUI

struct EpisodeCard : View {
    @State var episode = ""
    var body: some View {
        HStack(spacing: 0) {
            ZStack{
                Image("episode")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 120)
                VStack {
                    Spacer()
                    HStack {
                        
                    ZStack{
                        Rectangle()
                            .foregroundColor(.black)
                            .opacity(0.58)
                            .frame(width: 28, height: 18)
                        Text("23m")
                            .fontWeight(.medium)
                            .font(.system(size: 10))
                    }
                    .padding(.bottom, 10)
                    .padding(.leading, 110)
                    
                    }
                }
            }
            ZStack {
                Rectangle()
                    .foregroundColor(.customBlue)
                    .frame(height: 120)
                VStack {
                    HStack {
                        Text("E\(episode) - Title \(episode)")
                            .font(.system(size: 15))
                            .fontWeight(.semibold)
                        Spacer()
                    }
                    .padding(.leading, 10)
                    .padding(.top, 10)
                    Spacer()
                    HStack {
                        Spacer()
                        Image(systemName: "arrow.down.circle")
                            .font(.system(size: 25))
                            .foregroundColor(.white)
                            .padding(.bottom, 10)
                            .padding(.trailing, 10)
                        
                    }
                }
            }
        }
    }
}
