//
//  AnimeRow.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 10/12/21.
//

import Foundation
import SwiftUI

struct AnimeRow: View {
    var anime: Anime
    @EnvironmentObject var appData: AppData

    var body: some View {
        
        HStack(spacing: 0) {
            Image(anime.imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 120)
            
            ZStack {
                Rectangle()
                    .foregroundColor(.customBlue)
                    .frame(height: 120)
                VStack(alignment: .leading) {
                    Text(anime.name)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                            /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                        }
                        .padding(.top, 10)
                    Spacer()
                    HStack {
                        if anime.isDubbed == true {
                            Group {
                                Text(anime.category)
                                    .font(.system(size: 10))
                                    .fontWeight(.regular)
                                    .foregroundColor(.customCyan)
                                    .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                    }
                                Text("✦   DUBBED")
                                    .font(.system(size: 10))
                                    .fontWeight(.regular)
                                    .foregroundColor(.white)
                                Spacer()
                            }
                        } else {
                            Text(anime.category)
                                .font(.system(size: 10))
                                .fontWeight(.regular)
                                .foregroundColor(.customCyan)
                            Spacer()
                        }
                        Button{
                            appData.saveInFavourite(anime)
                        } label: {
                            if anime.isSaved == false {
                                Image(systemName: "bookmark")
                                    .foregroundColor(.customOrange)
                            } else if anime.isSaved == true {
                                Image(systemName: "bookmark.fill")
                                    .foregroundColor(.customOrange)
                            }
                        }
                        .padding(.trailing, 15)
                        .padding(.bottom, 15)
                    }
                    
                }
                .padding(.leading, 15)
            }
        }
    }
}
