//
//  FirstAnimeHome.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 10/12/21.
//

import SwiftUI

struct FirstAnimeHome: View {
    var animeList: [Anime]
    var body: some View {
        VStack {
            if let randomIndex = Int.random(in: animeList.indices) {
                ZStack {
                    Image(animeList[randomIndex].imageName)
                        .resizable()
                        .scaledToFit()
                    Rectangle()
                        .foregroundColor(.black)
                        .opacity(0.3)
                    Rectangle()
                        .foregroundColor(.clear)
                        .background(LinearGradient(gradient: Gradient(colors: [.clear, .black]), startPoint: .top, endPoint: .bottom))
                    
                    VStack(alignment: .leading) {
                        Spacer()
                        Text(animeList[randomIndex].name)
                            .foregroundColor(.white)
                            .font(.system(size: 25))
                            .fontWeight(.bold)
                        Text(animeList[randomIndex].description)
                        
                            .foregroundColor(.white)
                            .font(.system(size: 15))
                            .fontWeight(.light)
                            .multilineTextAlignment(.leading)
                            .frame(height: 70)
                        HStack {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.customOrange)
                                    .frame(width: 170, height: 45)
                                HStack {
                                    Image(systemName: "play")
                                        .foregroundColor(.black)
                                        .font(.system(size: 25))
                                    Text("WATCH NOW")
                                        .foregroundColor(.black)
                                        .fontWeight(.semibold)
                                }
                            }
                            Spacer()
                        }
                    }
                    .padding(.leading, 15)
                    .padding(.trailing, 15)
                }
            }
        }
    }
}

