//
//  AnimeDetails.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 08/12/21.
//

import SwiftUI

struct AnimeDetails: View {
    var anime : Anime
    @EnvironmentObject var appData : AppData
   @AppStorage("isFavourite") var isFavourite = false
    let fullStar = 5
    
    var body: some View {
        VStack {
            AnimeDetailBar(anime: anime, isFavourite: $isFavourite)
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    ZStack {
                        Image(anime.imageName)
                            .resizable()
                            .scaledToFit()
                        Rectangle()
                            .foregroundColor(.clear)
                            .background(LinearGradient(gradient: Gradient(colors: [.clear, .clear, .black]), startPoint: .top, endPoint: .bottom))
                    }
                    VStack(alignment: .leading) {
                        Spacer()
                        Text(anime.name)
                            .font(.system(size: 25))
                            .fontWeight(.medium)
                            .padding(.bottom, 5)
                        HStack {
                            if anime.isDubbed == true {
                                Group {
                                    Text(anime.category)
                                        .font(.system(size: 10))
                                        .fontWeight(.regular)
                                        .foregroundColor(.customCyan)
                                        .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                            /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                        }
                                    Text("✦   DUBBED")
                                        .font(.system(size: 10))
                                        .fontWeight(.regular)
                                        .foregroundColor(.white)
                                    Spacer()
                                }
                            } else {
                                Text(anime.category)
                                    .font(.system(size: 10))
                                    .fontWeight(.regular)
                                    .foregroundColor(.customCyan)
                                    .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                    }
                                Spacer()
                            }
                        }
                    }
                    .padding(.leading, 15)
                    
                    //                        Stars Value Random
                    HStack(spacing: 2) {
                        if let randomInt = Int.random(in: 1..<6) {
                            ForEach(1...randomInt, id:\.self) { star in
                                Image(systemName: "star.fill")
                            }
                            if randomInt == 5 {
                                Text("")
                            } else {
                                ForEach(randomInt...fullStar-1, id:\.self) { star in
                                    Image(systemName: "star")
                                }
                            }
                            Text("   Average: \(String(randomInt)).0")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                        Spacer()
                    }
                    .padding(.leading, 15)
                    Divider()
                    //                    Show Description
                    VStack(spacing: 20) {
                        Text(anime.description)
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .multilineTextAlignment(.leading)
                            .padding(.leading, 15)
                            .padding(.trailing, 15)
                        
                        
                        
                        //                        Episodes and More Like This section
                        VStack {
                            HStack(spacing:0) {
                                VStack(spacing: 0) {
                                    ZStack {
                                        Rectangle()
                                            .foregroundColor(.customGray)
                                        Text("EPISODES")
                                            .font(.system(size: 12))
                                            .foregroundColor(.white)
                                            .fontWeight(.semibold)
                                    }
                                    .frame(height: 40)
                                    Rectangle()
                                        .foregroundColor(.customOrange)
                                        .frame(height: 4)
                                }
                                VStack(spacing: 0) {
                                    ZStack {
                                        Rectangle()
                                            .foregroundColor(.customGray)
                                        Text("MORE LIKE THIS")
                                            .foregroundColor(.white)
                                            .font(.system(size: 12))
                                            .fontWeight(.semibold)
                                    }
                                    .frame(height: 40)
                                    Rectangle()
                                        .foregroundColor(.black)
                                        .frame(height: 4)
                                }
                            }
                            //                        Season and Sync (Only Design)
                            VStack(alignment: .leading) {
                                HStack {
                                    Image(systemName: "arrowtriangle.down.fill")
                                        .foregroundColor(.customCyan)
                                        .font(.system(size: 10))
                                        .padding(.leading, 15)
                                    
                                    Text("S1 - \(anime.name)")
                                        .foregroundColor(.customCyan)
                                        .fontWeight(.medium)
                                        .padding(.trailing, 15)
                                }
                                Divider()
                                HStack {
                                    Image(systemName: "list.dash")
                                        .foregroundColor(.white)
                                        .font(.system(size: 25))
                                    Spacer()
                                    Text("SYNC ALL")
                                        .foregroundColor(.white)
                                        .fontWeight(.semibold)
                                        .font(.system(size: 12))
                                    Image(systemName: "arrow.down.circle")
                                        .foregroundColor(.white)
                                        .font(.system(size: 25))
                                }
                                
                            }
                            .padding(.top, 10)
                            //                            Episodes
                            ForEach((1...anime.episodes),  id:\.self) { episode in
                                
                                EpisodeCard(episode: String(episode))
                            }
                            
                        }
                    }
                }
            }
            
            //                        Start "Watching" + Add Favorite
            
            
            
            HStack {
                ZStack {
                    Rectangle()
                        .foregroundColor(.customOrange)
                    HStack {
                        Image(systemName: "play")
                            .foregroundColor(.black)
                        Text("START WATCHING")
                            .foregroundColor(.black)
                    }
                    
                }
                .frame(height: 40)
                
                ZStack {
                    Rectangle()
                        .foregroundColor(.black)
                        .border(Color.customOrange, width: 1)
                    Button {
                        appData.saveInFavourite(anime)
                        isFavourite.toggle()
                        
                        print("iSaved is " + String(anime.isSaved) + ", Favourite is " + String(isFavourite))
                    } label : {
                        isFavourite ? Image(systemName: "bookmark.fill").foregroundColor(.customOrange) : Image(systemName: "bookmark").foregroundColor(.customOrange)
                    }
                }.frame(width: 40, height: 40)
            }
            .padding(.bottom, 10)
            
        }
        .onAppear {
            isFavourite = anime.isSaved
        }
    }
}
