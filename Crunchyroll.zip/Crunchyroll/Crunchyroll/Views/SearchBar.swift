//
//  SearchBar.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 16/12/21.
//

import SwiftUI


struct SearchBar: View {
    @Binding var searchText : String
    @Environment(\.presentationMode) var presentation
    
    var body: some View {
        HStack {
            ZStack {
                Rectangle()
                    .foregroundColor(.searchBar)
                
                HStack {
                    Image(systemName: "magnifyingglass")
                    TextField("Search...", text: $searchText)
                        .modifier(ClearButton(searchText: $searchText))
                }
                .foregroundColor(.gray)
                .padding()
            }
            .frame(height: 40)
            .cornerRadius(10)
            .padding(.leading, 10)
        }
    }
}

struct SearchBar_Previews: PreviewProvider {
    static var previews: some View {
        SearchBar(searchText: .constant(""))
    }
}

struct ClearButton: ViewModifier {
    @Binding var searchText: String
    func body(content: Content) -> some View {
        HStack {
            content
            if !searchText.isEmpty {
                Button(
                    action: { self.searchText = "" },
                    label: {
                        Image(systemName: "multiply.circle.fill")
                            .foregroundColor(.gray)
                    }
                )
            }
        }
    }
}
