//
//  AnimeCard.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 06/12/21.
//

import SwiftUI

struct AnimeCard: View {
    var anime: Anime
    @EnvironmentObject var appData: AppData
    
    var body: some View {
        VStack(spacing: 0) {
            Image(anime.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 200)
            
            ZStack {
                Rectangle()
                    .foregroundColor(.customBlue)
                VStack(alignment: .leading) {
                    Text(anime.name)
                        .font(.system(size: 15))
                        .fontWeight(.regular)
                        .foregroundColor(.white)
                        .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                        .padding(.top, 5)
                    
                    Spacer()
                    HStack {
                        if anime.isDubbed == true {
                            Group {
                                Text(anime.category)
                                    .font(.system(size: 10))
                                    .fontWeight(.regular)
                                    .foregroundColor(.customCyan)
                                    .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                    }
                                Text("✦   DUBBED")
                                    .font(.system(size: 10))
                                    .fontWeight(.regular)
                                    .foregroundColor(.white)
                                    .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                    }
                                Spacer()
                            }
                        } else {
                            Text(anime.category)
                                .font(.system(size: 10))
                                .fontWeight(.regular)
                                .foregroundColor(.customCyan)
                                .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                }
                            Spacer()
                        }
                        Button{
                            appData.saveInFavourite(anime)
                        } label: {
                            if anime.isSaved == false {
                                Image(systemName: "bookmark")
                                    .foregroundColor(.customOrange)
                                    .padding(.trailing, 10)
                                    .padding(.bottom, 5)
                            } else if anime.isSaved == true {
                                Image(systemName: "bookmark.fill")
                                    .foregroundColor(.customOrange)
                                    .padding(.trailing, 10)
                                    .padding(.bottom, 5)
                            }
                        }
                    }
                }
                
                .padding(.bottom, 5)
                .padding(.leading, 10)
            }
            .frame(width: 200, height: 85)
            
        }
        .padding(.leading, 5)
        .padding(.trailing, 5)
    }
}
