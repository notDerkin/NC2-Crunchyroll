//
//  SearchView.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 15/12/21.
//
import Foundation
import SwiftUI

struct SearchView: View {
    @Environment(\.presentationMode) var presentation
    @EnvironmentObject var appData : AppData
    @State var searchText = ""
    @State private var selectedAnime : Anime? = nil
    @State var isShowingAnime = false
    var body: some View {
        NavigationView {
            
            VStack {
                HStack {
                SearchBar(searchText: $searchText)
                    ZStack {
                        Rectangle()
                            .foregroundColor(.clear)
                    Text("Cancel")
                        .foregroundColor(.white)
                        
                    }
                    .frame(width: 60, height: 40)
                    .padding(.trailing, 10)
                    .onTapGesture {
                        self.presentation.wrappedValue.dismiss()
                    }
                }
                ScrollView {
                    ForEach(appData.animeList.filter({ (theAnime: Anime) -> Bool in
                        return (theAnime.name.range(of: searchText) != nil) || searchText == ""

                    })) { anime in
                        AnimeRow(anime: anime).onTapGesture {
                            self.searchText = ""
                            isShowingAnime.toggle()
                            self.selectedAnime = anime
                        }.fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                            AnimeDetails(anime: selectedAnime)
                        })
                        
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}
