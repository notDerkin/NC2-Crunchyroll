//
//  AnimeAd.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 10/12/21.
//

import Foundation
import SwiftUI

struct AnimeAd: View {
    var anime: Anime
    @EnvironmentObject var appData: AppData
    var body: some View {
        VStack {
            ZStack {
                VStack(spacing: 0) {
                    Image("animeAd")
                        .resizable()
                        .scaledToFill()
                    
                    Rectangle()
                        .foregroundColor(.customBlue)
                        .frame(width: 400, height: 150)
                }
                VStack {
                    Spacer()
                    HStack {
                        Image(anime.imageName)
                            .resizable()
                            .scaledToFit()
                            .shadow(radius: 5)
                            .frame(width: 120)
                            .padding(.leading, 15)
                            .padding(.bottom, 15)
                        
                        VStack {
                            VStack(alignment: .leading) {
                                Spacer()
                                Text(anime.name)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                    .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                    }
                                    .padding(.top, 20)
                                    .padding(.bottom, 1)
                                Text(anime.description)
                                    .foregroundColor(.white)
                                    .padding(.trailing, 15)
                            }
                            .frame(height: 130)
                            HStack {
                                if anime.isDubbed == true {
                                    Group {
                                        Text(anime.category)
                                            .font(.system(size: 10))
                                            .fontWeight(.regular)
                                            .foregroundColor(.customCyan)
                                        Text("✦   DUBBED")
                                            .font(.system(size: 10))
                                            .fontWeight(.regular)
                                            .foregroundColor(.white)
                                        Spacer()
                                            .padding(.trailing, 10)
                                            .padding(.bottom, 10)
                                    }
                                } else {
                                    HStack {
                                        Text(anime.category)
                                            .font(.system(size: 10))
                                            .fontWeight(.regular)
                                            .foregroundColor(.customCyan)
                                            .alignmentGuide(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Guide@*/.leading/*@END_MENU_TOKEN@*/) { dimension in
                                                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/dimension[.top]/*@END_MENU_TOKEN@*/
                                            }
                                        Spacer()
                                    }
                                }
                                Button{
                                    appData.saveInFavourite(anime)
                                } label: {
                                    if anime.isSaved == false {
                                        Image(systemName: "bookmark")
                                            .foregroundColor(.customOrange)
                                            .padding(.trailing, 5)
                                    } else if anime.isSaved == true {
                                        Image(systemName: "bookmark.fill")
                                            .foregroundColor(.customOrange)
                                            .padding(.trailing, 5)
                                    }
                                }
                                .padding(.trailing, 10)
                                .padding(.bottom, 10)
                            }
                        }
                    }
                }
            }
        }
        .padding(.leading, 15)
        .padding(.trailing, 15)
    }
}
