//
//  AnimeList.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 06/12/21.
//

import SwiftUI

struct AnimeList: View {
    var animeList: [Anime]
    @State private var selectedAnime : Anime? = nil
    @State var isShowingAnime = false
    
    var body: some View {
        NavigationView {
            VStack {
                CustomNavBar()
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 100) {
                        
                        //                    Random Anime Show Up
                        VStack {
                            if let randomIndex = Int.random(in: animeList.indices) {
                                
                                ZStack {
                                    Image(animeList[randomIndex].imageName)
                                        .resizable()
                                        .scaledToFit()
                                    Rectangle()
                                        .foregroundColor(.black)
                                        .opacity(0.3)
                                    Rectangle()
                                        .foregroundColor(.clear)
                                        .background(LinearGradient(gradient: Gradient(colors: [.clear, .black]), startPoint: .top, endPoint: .bottom))
                                    
                                    VStack(alignment: .leading) {
                                        Spacer()
                                        Text(animeList[randomIndex].name)
                                            .foregroundColor(.white)
                                            .font(.system(size: 25))
                                            .fontWeight(.bold)
                                        Text(animeList[randomIndex].description)
                                        
                                            .foregroundColor(.white)
                                            .font(.system(size: 15))
                                            .fontWeight(.light)
                                            .multilineTextAlignment(.leading)
                                            .frame(height: 70)
                                        HStack {
                                            ZStack {
                                                Rectangle()
                                                    .foregroundColor(.customOrange)
                                                    .frame(width: 170, height: 45)
                                                HStack {
                                                    Image(systemName: "play")
                                                        .foregroundColor(.black)
                                                        .font(.system(size: 25))
                                                    Text("WATCH NOW")
                                                        .foregroundColor(.black)
                                                        .fontWeight(.semibold)
                                                }
                                            }
                                            Spacer()
                                        }
                                    }
                                    
                                    .padding(.leading, 15)
                                    .padding(.trailing, 15)
                                }
                                .onTapGesture {
                                    isShowingAnime.toggle()
                                    self.selectedAnime = animeList[randomIndex]
                                }.fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                    AnimeDetails(anime: selectedAnime)
                                })
                            }
                        }
                        
                        
                        //                    Top Picks animeList
                        ScrollView(.horizontal, showsIndicators: false) {
                            VStack(alignment: .leading) {
                                Text("TOP PICKS FOR YOU")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding(.leading, 20)
                                HStack {
                                    ForEach(animeList.filter({$0.isTopForYou})) { anime in
                                        AnimeCard(anime: anime)
                                            .onTapGesture {
                                                isShowingAnime.toggle()
                                                self.selectedAnime = anime
                                            }
                                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                                AnimeDetails(anime: selectedAnime)
                                            })
                                    }
                                }
                                .padding(.leading, 15)
                            }
                        }
                        .frame(height: 270)
                        
                        //                      Anime Ad
                        
                        AnimeAd(anime: animeList[7])
                            .onTapGesture {
                                isShowingAnime.toggle()
                                self.selectedAnime = animeList[7]
                            }
                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                AnimeDetails(anime: selectedAnime)
                            })
                        
                        
                        //                    Most Popular animeList
                        ScrollView(.horizontal, showsIndicators: false) {
                            VStack(alignment: .leading){
                                Text("MOST POPULAR")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding(.leading, 20)
                                HStack {
                                    ForEach(animeList.filter({$0.isPopular})) { anime in
                                        AnimeCard(anime: anime)
                                            .onTapGesture {
                                                isShowingAnime.toggle()
                                                self.selectedAnime = anime
                                            }
                                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                                AnimeDetails(anime: selectedAnime)
                                            })
                                    }
                                }
                                .padding(.leading, 15)
                            }
                        }
                        .frame(height: 270)
                        
                        //                      Anime Ad
                        AnimeAd(anime: animeList[12])
                            .onTapGesture {
                                isShowingAnime.toggle()
                                self.selectedAnime = animeList[12]
                            }
                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                AnimeDetails(anime: selectedAnime)
                            })
                        
                        //                    Updated animeList
                        ScrollView(.horizontal, showsIndicators: false) {
                            VStack(alignment: .leading){
                                Text("JUST UPDATED ON CRUNCHYROLL")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding(.leading, 20)
                                HStack {
                                    ForEach(animeList.filter({$0.isUpdated})) { anime in
                                        AnimeCard(anime: anime)
                                            .onTapGesture {
                                                isShowingAnime.toggle()
                                                self.selectedAnime = anime
                                            }
                                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                                AnimeDetails(anime: selectedAnime)
                                            })
                                    }
                                }
                                .padding(.leading, 15)
                            }
                        }
                        .frame(height: 270)
                        
                        //                      Anime Ad
                        AnimeAd(anime: animeList[21])
                            .onTapGesture {
                                isShowingAnime.toggle()
                                self.selectedAnime = animeList[21]
                            }
                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                AnimeDetails(anime: selectedAnime)
                            })
                        
                        //                    Crunchyroll Originals animeList
                        ScrollView(.horizontal, showsIndicators: false) {
                            VStack(alignment: .leading){
                                Text("CRUNCHYROLL HELPED MAKE THESE!")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding(.leading, 20)
                                HStack {
                                    ForEach(animeList.filter({$0.isOriginal})) { anime in
                                        AnimeCard(anime: anime)
                                            .onTapGesture {
                                                isShowingAnime.toggle()
                                                self.selectedAnime = anime
                                            }
                                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                                AnimeDetails(anime: selectedAnime)
                                            })
                                    }
                                }
                                .padding(.leading, 15)
                            }
                        }
                        .frame(height: 270)
                        
                        //                      Anime Ad
                        AnimeAd(anime: animeList[30])
                            .onTapGesture {
                                isShowingAnime.toggle()
                                self.selectedAnime = animeList[30]
                            }
                            .fullScreenCover(item: $selectedAnime, content: { selectedAnime in
                                AnimeDetails(anime: selectedAnime)
                            })
                    }
                }
                
            }
            .navigationBarHidden(true)
        }
    }
}
