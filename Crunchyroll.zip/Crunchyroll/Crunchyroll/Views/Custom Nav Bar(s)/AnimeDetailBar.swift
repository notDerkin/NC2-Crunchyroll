//
//  AnimeDetailBar.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 10/12/21.
//

import Foundation
import SwiftUI

struct AnimeDetailBar: View {
    var anime: Anime
    @Environment(\.presentationMode) var presentation
    @Binding var isFavourite : Bool
    
    var body: some View {
        HStack {
            Image(systemName: "multiply")
                .onTapGesture {
                    isFavourite = anime.isSaved
                    self.presentation.wrappedValue.dismiss()
                }
                .foregroundColor(.white)
                .scaleEffect(1.7)
                .padding(.leading, 10)
            Image(systemName: "multiply")
                .foregroundColor(.clear)
                .scaleEffect(1.7)
                .padding(.leading, 10)
            Spacer()
            Text(anime.name)
                .foregroundColor(.white)
                .fontWeight(.semibold)
            Spacer()
            Image(systemName: "tv")
                .foregroundColor(.white)
                .scaleEffect(1.2)
                .padding(.trailing, 10)
            
            Image(systemName: "arrowshape.turn.up.right")
                .foregroundColor(.white)
                .scaleEffect(1.2)
                .padding(.trailing, 10)
        }
        .frame(height: 45)
        .background(Color.black.ignoresSafeArea(edges: .top))
    }
}
