//
//  CustomNavBar.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 08/12/21.
//

import SwiftUI

struct CustomNavBar: View {
//    var anime : Anime
    @State var isSearching = false
    
    var body: some View {
        HStack {
            Image("Artboard")
                .resizable()
                .scaledToFit()
                .padding(.leading, 10)
                .padding(.trailing, 140)
            Spacer()
            Image(systemName: "tv")
                .foregroundColor(.white)
                .scaleEffect(1.2)
                .padding(.trailing, 10)
            
            Image(systemName: "magnifyingglass")
                .foregroundColor(.white)
                .scaleEffect(1.2)
                .padding(.trailing, 10)
                .onTapGesture {
                    self.isSearching = true
                }.fullScreenCover(isPresented: $isSearching) {
                    SearchView()
                }
        }
        .background(Color.black.ignoresSafeArea(edges: .top))
    }
}
