//
//  MyListNavBar.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 10/12/21.
//

import Foundation
import SwiftUI

struct MyListNavBar: View {
    var body: some View {
        HStack {
            Spacer()
            Text("My List")
                .foregroundColor(.white)
                .fontWeight(.semibold)
                .padding(.leading, 70)
            Spacer()
            Image(systemName: "tv")
                .foregroundColor(.white)
                .scaleEffect(1.2)
                .padding(.trailing, 10)
            
            Image(systemName: "magnifyingglass")
                .foregroundColor(.white)
                .scaleEffect(1.2)
                .padding(.trailing, 10)
        }
        .frame(height: 43)
        .background(Color.black.ignoresSafeArea(edges: .top))
    }
}
