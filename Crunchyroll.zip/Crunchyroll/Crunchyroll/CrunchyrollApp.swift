//
//  CrunchyrollApp.swift
//  Crunchyroll
//
//  Created by Raffaele Siciliano on 06/12/21.
//

import SwiftUI

@main
struct CrunchyrollApp: App {
    var body: some Scene {
        WindowGroup {
            let appData = AppData()
            MainView().preferredColorScheme(.dark).environmentObject(appData)
        }
    }
}
